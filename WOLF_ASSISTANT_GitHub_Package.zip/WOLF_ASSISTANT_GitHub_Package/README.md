# WOLF ASSISTANT — Android starter package

This is a **starter project**, not a finished autonomous assistant. It includes an Arabic Android chat screen, an optional HTTPS backend connection, a small Node.js proxy example, and a GitHub Actions workflow to build a debug APK.

## Requirements
- Android Studio with JDK 17 / Android SDK
- Node.js 20+ only if running the backend
- An AI provider API key configured on the backend host (never put keys in the Android app or GitHub source)

## Build the Android app
1. Open this folder in Android Studio.
2. Allow Gradle to sync and install the requested Android SDK if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.

## Optional backend
From `backend/` run `npm install`, then set `PORT`, `AI_API_KEY`, and optionally `AI_API_URL` in the server environment, then run `npm start`. Deploy it behind HTTPS. Set the Android app's backend URL in `MainActivity.kt` (`BACKEND_URL`) to your deployed `/chat` endpoint. Do not use a plain HTTP URL in production.

The proxy example expects an OpenAI-compatible chat-completions endpoint. Provider details and API key stay on the server.

## Current limitations
- Chat history is temporary and held in memory.
- Voice, persistent memory, phone control, and self-improvement are not implemented.
- The app needs a deployed backend URL and a configured provider key to receive AI responses.
- The workflow builds an APK; it does not install or test the APK on a physical phone.

See `ROADMAP_AR.md` for the development plan.
