package com.wolfassistant.app

import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {
    companion object {
        // Replace with your deployed HTTPS backend /chat endpoint. Keep blank for local demo mode.
        private const val BACKEND_URL = ""
    }

    private lateinit var messages: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var send: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(21, 32, 43)
        window.navigationBarColor = android.graphics.Color.rgb(21, 32, 43)
        buildUi()
        addMessage("مساعد الذئب", "أهلًا بك! أنا النسخة التجريبية من مساعد الذئب. كيف أستطيع مساعدتك؟")
    }

    private fun buildUi() {
        val base = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(12))
            setBackgroundColor(android.graphics.Color.rgb(15, 23, 32))
        }
        val title = TextView(this).apply {
            text = "🐺 مساعد الذئب"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            setPadding(0, dp(8), 0, dp(16))
        }
        scroll = ScrollView(this)
        messages = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(8)) }
        scroll.addView(messages)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        input = EditText(this).apply {
            hint = "اكتب رسالتك هنا..."
            textSize = 16f
            setTextColor(android.graphics.Color.WHITE)
            setHintTextColor(android.graphics.Color.LTGRAY)
            setBackgroundColor(android.graphics.Color.rgb(35, 47, 61))
            setPadding(dp(12), dp(8), dp(12), dp(8))
            layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        }
        send = Button(this).apply { text = "إرسال"; setOnClickListener { sendMessage() } }
        row.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(send, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        base.addView(title)
        base.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        base.addView(row)
        setContentView(base)
    }

    private fun sendMessage() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        addMessage("أنت", text)
        input.setText("")
        if (BACKEND_URL.isBlank()) {
            addMessage("مساعد الذئب", "واجهة التجربة تعمل. لتفعيل ردود الذكاء الاصطناعي، انشر الخادم الموجود في مجلد backend ثم ضع رابط HTTPS في BACKEND_URL داخل MainActivity.kt.")
            return
        }
        send.isEnabled = false
        addMessage("مساعد الذئب", "جارٍ التفكير...")
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { requestBackend(text) }
            if (messages.childCount > 0) messages.removeViewAt(messages.childCount - 1)
            addMessage("مساعد الذئب", result)
            send.isEnabled = true
        }
    }

    private fun requestBackend(message: String): String {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(BACKEND_URL).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 30000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            val payload = JSONObject().put("message", message).toString()
            connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            if (connection.responseCode !in 200..299) "تعذر الاتصال بالخادم (${connection.responseCode}). تحقق من إعداداته." 
            else JSONObject(body).optString("reply", "لم يصل رد مفهوم من الخادم.")
        } catch (e: Exception) {
            "تعذر الاتصال بالخادم. تحقق من الإنترنت ورابط HTTPS. (${e.localizedMessage ?: "خطأ غير معروف"})"
        } finally { connection?.disconnect() }
    }

    private fun addMessage(who: String, body: String) {
        val view = TextView(this).apply {
            text = "$who
$body"
            textSize = 16f
            setTextColor(android.graphics.Color.WHITE)
            setBackgroundColor(if (who == "أنت") android.graphics.Color.rgb(39, 67, 58) else android.graphics.Color.rgb(35, 47, 61))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        }
        val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        params.setMargins(0, 0, 0, dp(10))
        messages.addView(view, params)
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
