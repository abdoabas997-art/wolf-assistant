const express = require('express');
const app = express();
app.use(express.json({ limit: '32kb' }));
const port = Number(process.env.PORT || 3000);
const apiKey = process.env.AI_API_KEY;
const apiUrl = process.env.AI_API_URL || 'https://api.openai.com/v1/chat/completions';
const model = process.env.AI_MODEL || 'gpt-4o-mini';

app.get('/health', (_req, res) => res.json({ ok: true, service: 'wolf-assistant-proxy' }));
app.post('/chat', async (req, res) => {
  const message = typeof req.body?.message === 'string' ? req.body.message.trim() : '';
  if (!message) return res.status(400).json({ error: 'message is required' });
  if (message.length > 8000) return res.status(413).json({ error: 'message too long' });
  if (!apiKey) return res.status(503).json({ error: 'AI_API_KEY is not configured on the server' });
  try {
    const upstream = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model, messages: [
        { role: 'system', content: 'أنت مساعد الذئب، مساعد ذكي مهذب ومفيد. أجب باللغة العربية ما لم يطلب المستخدم غير ذلك.' },
        { role: 'user', content: message }
      ] })
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error('AI provider returned status', upstream.status);
      return res.status(502).json({ error: 'AI provider request failed' });
    }
    const reply = data.choices?.[0]?.message?.content;
    if (typeof reply !== 'string') return res.status(502).json({ error: 'AI provider response format was unexpected' });
    return res.json({ reply });
  } catch (err) {
    console.error('Proxy request failed:', err.message);
    return res.status(502).json({ error: 'Could not reach AI provider' });
  }
});
app.listen(port, '0.0.0.0', () => console.log(`Wolf proxy listening on ${port}`));
