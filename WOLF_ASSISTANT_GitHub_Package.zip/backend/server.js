import express from "express";

const app = express();
app.use(express.json({ limit: "64kb" }));
const port = Number(process.env.PORT || 3000);
const apiKey = process.env.MODEL_API_KEY;
const baseUrl = (process.env.MODEL_BASE_URL || "https://api.openai.com/v1").replace(/\/+$/, "");
const model = process.env.MODEL_NAME || "gpt-4o-mini";

app.get("/health", (_req, res) => res.json({ ok: true, service: "wolf-assistant-backend" }));

app.post("/chat", async (req, res) => {
  if (!apiKey) return res.status(503).json({ error: "Server model key is not configured." });
  const messages = req.body?.messages;
  if (!Array.isArray(messages) || messages.length === 0 || messages.length > 40)
    return res.status(400).json({ error: "messages must be a non-empty array of at most 40 items." });

  const safeMessages = messages
    .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
    .map(m => ({ role: m.role, content: m.content.slice(0, 6000) }));
  if (!safeMessages.length) return res.status(400).json({ error: "No valid chat messages supplied." });

  try {
    const upstream = await fetch(`${baseUrl}/chat/completions`, {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model,
        messages: [{ role: "system", content: "You are WOLF ASSISTANT, a helpful Arabic-first assistant. Reply in the user's language. Be honest about limitations and never claim to have performed phone actions." }, ...safeMessages],
        temperature: 0.7
      })
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error("Model provider returned HTTP", upstream.status);
      return res.status(502).json({ error: "The model provider request failed." });
    }
    const reply = data?.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim())
      return res.status(502).json({ error: "The model provider returned no text reply." });
    return res.json({ reply });
  } catch (error) {
    console.error("Model request failed:", error?.message || "unknown error");
    return res.status(502).json({ error: "Could not reach the model provider." });
  }
});
app.listen(port, () => console.log(`WOLF ASSISTANT backend listening on port ${port}`));
