plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.wolfassistant"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.wolfassistant"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0"
        // Set this to your deployed HTTPS backend URL ending in /chat.
        buildConfigField("String", "AI_BACKEND_URL", "\"\"")
    }
    buildFeatures { viewBinding = false; buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
