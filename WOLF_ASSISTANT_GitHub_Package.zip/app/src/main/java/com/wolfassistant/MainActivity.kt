package com.wolfassistant

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var transcript: LinearLayout
    private lateinit var input: EditText
    private lateinit var sendButton: Button
    private val executor = Executors.newSingleThreadExecutor()
    private val history = JSONArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(18, 22, 33))
        }
        val title = TextView(this).apply {
            text = "WOLF ASSISTANT"; textSize = 25f
            setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "مساعد الذئب • نسخة تجريبية"; textSize = 16f
            setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }
        root.addView(subtitle, matchWrap())
        val scroll = ScrollView(this)
        transcript = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(4, 20, 4, 20)
        }
        scroll.addView(transcript)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        input = EditText(this).apply {
            hint = "اكتب رسالتك هنا..."; setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE); setSingleLine(false)
            setBackgroundColor(Color.rgb(36, 43, 58)); setPadding(16, 12, 16, 12)
        }
        root.addView(input, matchWrap())
        sendButton = Button(this).apply {
            text = "إرسال"; setOnClickListener { sendMessage() }
        }
        root.addView(sendButton, matchWrap())
        setContentView(root)
        addMessage("مساعد الذئب", "أهلًا! اربط خادم الذكاء الاصطناعي لتفعيل الردود الذكية.")
    }

    private fun sendMessage() {
        val message = input.text.toString().trim()
        if (message.isEmpty()) return
        input.setText("")
        addMessage("أنت", message)
        history.put(JSONObject().put("role", "user").put("content", message))
        val endpoint = BuildConfig.AI_BACKEND_URL.trim()
        if (endpoint.isEmpty()) {
            addMessage("مساعد الذئب", "إعداد رابط خادم الذكاء الاصطناعي مطلوب. راجع README.md.")
            return
        }
        sendButton.isEnabled = false
        executor.execute {
            val answer = try { requestAI(endpoint, history) }
            catch (_: Exception) { "تعذر الاتصال بالخادم. تحقق من رابط HTTPS والإعدادات." }
            runOnUiThread {
                sendButton.isEnabled = true
                addMessage("مساعد الذئب", answer)
                history.put(JSONObject().put("role", "assistant").put("content", answer))
            }
        }
    }

    private fun requestAI(endpoint: String, messages: JSONArray): String {
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        try {
            val body = JSONObject().put("messages", messages)
                .toString().toByteArray(StandardCharsets.UTF_8)
            connection.outputStream.use { it.write(body) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("Backend error: $code")
            return JSONObject(response).optString("reply", "لم يصل رد مفهوم من الخادم.")
        } finally { connection.disconnect() }
    }

    private fun addMessage(who: String, message: String) {
        val view = TextView(this).apply {
            text = "$who:\n$message"; textSize = 16f
            setTextColor(Color.WHITE); setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.rgb(36, 43, 58))
        }
        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        params.bottomMargin = 12
        transcript.addView(view, params)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
