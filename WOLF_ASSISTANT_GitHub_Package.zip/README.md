# WOLF ASSISTANT — مساعد الذئب

حزمة تأسيسية لتطبيق Android، وليست مساعدًا نهائيًا مكتملًا.

## المحتويات
- تطبيق Android بواجهة محادثة عربية أولية.
- نقطة اتصال بخادم AI عبر HTTPS.
- خادم Node.js وسيط يحفظ مفتاح النموذج على الخادم.
- GitHub Actions لبناء APK تجريبي.
- خريطة طريق للصوت والذاكرة والتحكم الآمن بالهاتف.

## مهم
لا يحتوي ZIP على نموذج ذكاء اصطناعي أو مفتاح API. يلزم نشر `backend/` على استضافة HTTPS وإضافة مفتاح المزود كسرّ في إعدادات الخادم. لا ترفع المفاتيح إلى GitHub. المحادثة مؤقتة؛ الصوت والذاكرة الدائمة والتحكم بالهاتف لم تُنفذ بعد. لم يتم تأكيد نجاح بناء APK بعد.

## الملفات الموجودة أصلًا في مستودعك
الحزمة تتضمن نسخًا محدثة من الملفات الأساسية التي قرأناها في `wolf-assistant`: `README.md`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `app/build.gradle.kts`, `app/src/main/AndroidManifest.xml`, `app/src/main/java/com/wolfassistant/MainActivity.kt`.
وتضيف `.gitignore`، و`.github/workflows/android-build.yml`، ومجلد `backend/`، و`ROADMAP_AR.md`.

## رفع الحزمة
1. فك ضغط الملف.
2. ارفع **محتويات** المجلد إلى جذر مستودع `wolf-assistant` على GitHub، مع الحفاظ على مسارات المجلدات.
3. اعمل Commit على `main`.
4. افتح **Actions** ثم **Build WOLF ASSISTANT APK**.
5. عند نجاح البناء، نزّل `WOLF-ASSISTANT-debug-apk` من Artifacts.

تأكد من رفع `.github/workflows/` لأنه مجلد مخفي.

## ربط الذكاء الاصطناعي
- انشر `backend/` على خادم HTTPS.
- اضبط `MODEL_API_KEY`, `MODEL_BASE_URL`, `MODEL_NAME` في إعدادات الخادم.
- ضع رابط `/chat` في `AI_BACKEND_URL` داخل `app/build.gradle.kts` ثم أعد البناء.
- لا تضع مفتاح API داخل تطبيق Android.
